﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using static Wpf.MainWindow;

namespace Wpf
{
    public class StateObject
    {
        // Client socket.  
        public Socket workSocket = null;
        // Size of receive buffer.  
        public const int BufferSize = 256;
        // Receive buffer.  
        public byte[] buffer = new byte[BufferSize];
        // Received data string.  
        public StringBuilder sb = new StringBuilder();
    }


    public class Connection
    {

        private static ManualResetEvent connectDone =
            new ManualResetEvent(false);
        private static ManualResetEvent sendDone =
            new ManualResetEvent(false);
        private static ManualResetEvent receiveDone =
            new ManualResetEvent(false);

        // The response from the remote device.  
        private static String response = String.Empty;

        private String response_FL = String.Empty;

        private Registration window;

        private string myTag = "";
        private string myName = "";
        private string myPwd = "";

        private string friendName = "";

        private string currMessage = "";

        private const string REGISTER_OK = "ACKR";
        private const string REGISTER_NOK = "NACKR";

        private const string LOGIN_OK = "ACKL";
        private const string LOGIN_NOK = "NACKL";

        private const string FRIEND_LIST = "<RFL>";

        private const string FRIEND_REQUEST_OK = "ACKFR";
        private const string FRIEND_REQUEST_NOK_TAG = "NACKFR_T";
        private const string FRIEND_REQUEST_NOK_ADD = "NACKFR_A";

        private const string REMOVE_FRIEND_OK = "ACKRF";
        private const string REMOVE_FRIEND_NOK = "NACKRF";

        private const string CHANGE_NAME_OK = "ACKCN";
        private const string CHANGE_NAME_NOK = "NACKCN";

        private const string INCOMING_FRIEND_REQUEST = "<IFR>";

        private const string FRIEND_REQUEST_ACCEPTED = "<FRA>";

        private const int port = 11000;


        //private static IPAddress ipAddress = IPAddress.Parse("172.17.61.166");
        //private static IPAddress ipAddress = IPAddress.Parse("10.0.0.11");
        private static IPAddress ipAddress = IPAddress.Parse("10.0.0.15");
        private IPEndPoint remoteEP = new IPEndPoint(ipAddress, port);

        // Create a TCP/IP socket.  
        private Socket client = new Socket(ipAddress.AddressFamily,
            SocketType.Stream, ProtocolType.Tcp);

        private TextBox tb;

        public void SetFriendName(string value)
        {
            friendName = value;
        }

        public string GetFriendsList() { return response_FL; }

        public string GetName() { return myName; }

        public string GetTag() { return myTag; }

        /// <summary>
        /// Current status of the client, whether the socket is connected or not     
        /// </summary>
        /// <returns>True, if the client is connected. Otherwise false</returns>
        public bool IsConnected() { return client.Connected; }

        public Connection(TextBox ShowInputBlock)
        {
            tb = ShowInputBlock;
        }


        public void StartClient()
        {
            Thread listenThread = null;
            try
            {
                client.BeginConnect(remoteEP,
                           new AsyncCallback(ConnectCallback), client);
                connectDone.WaitOne();

                listenThread = new Thread(ListenForMessages);
                listenThread.IsBackground = true;
                listenThread.Start();
            }
            catch (SocketException ex)
            {
                MessageBox.Show("Error while starting");


            }
        }


        public void SignAccount(string username, string password, SignType type, Registration window)
        {
            if (!SetUserInfo(username, password))
                return;

            if (type == SignType.Login)
                Send(client, myName + ";" + myPwd + "<EOL>");

            else if (type == SignType.Registration)
                Send(client, myName + ";" + myPwd + "<EOR>");

            sendDone.WaitOne();

            this.window = window;
        }

        private void SendFriendListRequest()
        {
            Send(client, myTag + ";<FLR>");
            sendDone.WaitOne();
        }

        public void SendFriendRequest(string tag) // Tag of the user, that should be added
        {
            Send(client, myTag + ";" + tag + "<PFR>"); //PendingFriendRequest
            sendDone.WaitOne();
        }

        public void SendMessage(string friendtag, string message, string myName)
        {
            Send(client, friendtag + ";" + message + ";" + myName);
            sendDone.WaitOne();
        }

        public void SendRemoveRequest(string friendTag)
        {
            Send(client, myTag + ";" + friendTag + "<RFR>");
            sendDone.WaitOne();
        }

        public void ChangeUserName(string newName)
        {
            Send(client, myTag + ";" + newName + "<CUN>");
            sendDone.WaitOne();
        }

        public void SendFriendRequestResponse(bool accepted, string senderTag)
        {
            if (accepted)
            {
                Send(client, "A" + ";" + myTag + ";" + senderTag + "<FRR>");
            }
            else
            {
                Send(client, "D" + ";" + myTag + ";" + senderTag + "<FRR>");
            }
        }

        private bool SetUserInfo(string username, string password)
        {
            if (username.Length == 0 || password.Length == 0)
                return false;

            myName = username;
            myPwd = password;

            return true;
        }

        private void ConnectCallback(IAsyncResult ar)
        {
            try
            {
                // Retrieve the socket from the state object.  
                Socket client = (Socket)ar.AsyncState;

                // Complete the connection.  
                client.EndConnect(ar);

                Console.WriteLine("Socket connected to {0}",
                    client.RemoteEndPoint.ToString());

                // Signal that the connection has been made.  
                connectDone.Set();
            }
            catch (Exception e)
            {
                MessageBox.Show("No connection could been established, please try again later", "Could not connect to server", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Receive(Socket client)
        {
            try
            {
                // Create the state object.  
                StateObject state = new StateObject();
                state.workSocket = client;

                // Begin receiving the data from the remote device.  
                client.BeginReceive(state.buffer, 0, StateObject.BufferSize, 0,
                    new AsyncCallback(ReceiveCallback), state);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }

        private void ReceiveCallback(IAsyncResult ar)
        {
            try
            {
                // Retrieve the state object and the client socket   
                // from the asynchronous state object.  
                StateObject state = (StateObject)ar.AsyncState;
                Socket client = state.workSocket;

                // Read data from the remote device.  
                int bytesRead = client.EndReceive(ar);

                string response = Encoding.ASCII.GetString(state.buffer, 0, bytesRead);

                if (response == LOGIN_NOK)
                {
                    MessageBox.Show("Invalid username password combination", "Failed to login", MessageBoxButton.OK, MessageBoxImage.Exclamation);

                }
                else if (response == REGISTER_NOK)
                {
                    MessageBox.Show("Username already taken", "Failed to register account", MessageBoxButton.OK, MessageBoxImage.Exclamation);

                }
                else if (response.StartsWith(LOGIN_OK))
                {
                    myTag = response.Split(';')[1];

                    SendFriendListRequest();

                    UpdateWindow d = new UpdateWindow(closeWindow);
                    window.Dispatcher.BeginInvoke(d);

                }
                else if (response.StartsWith(REGISTER_OK))
                {
                    myTag = response.Split(';')[1];

                    UpdateWindow d = new UpdateWindow(closeWindow);
                    window.Dispatcher.BeginInvoke(d);

                    MessageBox.Show("Registration success, welcome !");
                }
                else if (response.IndexOf(FRIEND_LIST) > -1 || response == "FLRF")
                {
                    if (response.Length != 4)
                    {
                        response_FL = response;
                    }
                }
                else if (response == FRIEND_REQUEST_OK)
                {
                    MessageBox.Show("Friend request sent!");
                }
                else if (response == FRIEND_REQUEST_NOK_TAG)
                {
                    MessageBox.Show("Tag not found");
                }
                else if (response == FRIEND_REQUEST_NOK_ADD)
                {
                    MessageBox.Show("Already sent a friend request to that user");
                }
                else if (response == REMOVE_FRIEND_OK)
                {
                    MessageBox.Show("Friend Removed");
                }
                else if (response == REMOVE_FRIEND_NOK)
                {
                    MessageBox.Show("Error: Friend could not be removed");
                }
                else if (response == CHANGE_NAME_OK)
                {
                    MessageBox.Show("Name successfully changed");
                }
                else if (response == CHANGE_NAME_NOK)
                {
                    MessageBox.Show("Name was not changed, try again later");
                }
                else if (response.IndexOf(INCOMING_FRIEND_REQUEST) > -1)
                {
                    UpdateWindowWithText d = new UpdateWindowWithText(openWindow);
                    Application.Current.Dispatcher.BeginInvoke(d, response);

                }
                else if (response.IndexOf(FRIEND_REQUEST_ACCEPTED) > -1)
                {
                    SendFriendListRequest();

                    UpdateWindow d = new UpdateWindow(closeWindow);
                    window.Dispatcher.BeginInvoke(d);
                }

                else //Normal Message
                {
                    string[] elem = response.Split(';');

                    currMessage = elem[2] + ": " + DateTime.Now.ToString("dd.MM.yy hh:mm") + "\n" + "    " + elem[1] + "\n";

                    if (elem[2] == friendName)
                    {
                        UpdateText updateDelegate = new UpdateText(updateMessage);
                        tb.Dispatcher.BeginInvoke(updateDelegate, currMessage);
                    }

                    File.AppendAllText(@".\" + elem[2] + ".txt", currMessage);

                }


                client.BeginReceive(state.buffer, 0, StateObject.BufferSize, 0,
                        new AsyncCallback(ReceiveCallback), state);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error while Reading", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public delegate void UpdateWindow();

        private void closeWindow()
        {
            window.Close();
            window.OpenMainWin();
        }

        public delegate void UpdateWindowWithText(string text);
        private void openWindow(string text)
        {

            string[] elem = text.Split(';');
            string senderName = elem[0];
            string senderTag = elem[1].Substring(elem[1].Length - 5);

            RequestWin rwin = new RequestWin(senderName, senderTag);
            rwin.SetConnection(this);
            rwin.Show();
        }


        public delegate void UpdateText(string text);

        private void updateMessage(string msg)
        {
            tb.Text += msg;
        }



        private void Send(Socket client, String data)
        {
            // Convert the string data to byte data using ASCII encoding.  
            byte[] byteData = Encoding.ASCII.GetBytes(data);

            // Begin sending the data to the remote device.  
            client.BeginSend(byteData, 0, byteData.Length, 0,
                new AsyncCallback(SendCallback), client);
        }

        private void SendCallback(IAsyncResult ar)
        {
            try
            {
                // Retrieve the socket from the state object.  
                Socket client = (Socket)ar.AsyncState;

                // Complete sending the data to the remote device.  
                int bytesSent = client.EndSend(ar);
                Console.WriteLine("Sent {0} bytes to server.", bytesSent);

                // Signal that all bytes have been sent.  
                sendDone.Set();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error while Sending", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void ListenForMessages()
        {
            for (;;)
            {
                Receive(client);
                receiveDone.WaitOne();
            }

        }



    }
}
