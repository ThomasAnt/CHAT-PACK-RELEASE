﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace Wpf
{
    /// <summary>
    /// Interaktionslogik für Registration.xaml
    /// </summary>
    public partial class Registration : Window
    {

        MainWindow w;
        Connection connection;

        public Registration GetInstance() { return this; }


        public Registration()
        {
            InitializeComponent();
            button_log_in.Click += button_log_in_Click;
            button_register.Click += button_register_Click;

            w = new Wpf.MainWindow();
            connection = w.GetConnection();
        }

        private void button_register_Click(object sender, RoutedEventArgs e)
        {
            if (passwordBox.Password != passwordBox_2.Password)
            {
                MessageBox.Show("Password don't match", "Wrong input", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {

                if (!connection.IsConnected())
                {
                    connection.StartClient();
                }

                connection.SignAccount(tboxUser.Text, passwordBox.Password, Wpf.MainWindow.SignType.Registration, this);
            }
        }

        private void button_log_in_Click(object sender, RoutedEventArgs e)
        {
            if (!connection.IsConnected())
            {
                connection.StartClient();
            }

            connection.SignAccount(tboxUser.Text, passwordBox.Password, Wpf.MainWindow.SignType.Login, this);

        }
        public void OpenMainWin()
        {

            w.tBoxName.Text = tboxUser.Text;
            w.Show();

            string fl;
            if ((fl = connection.GetFriendsList()) != String.Empty)
            {
                w.ReadResponse_FriendList(connection.GetFriendsList());
            }
        }

    }
}
