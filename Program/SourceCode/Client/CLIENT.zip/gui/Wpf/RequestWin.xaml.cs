﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf
{
    /// <summary>
    /// Interaction logic for RequestWin.xaml
    /// </summary>
    public partial class RequestWin : Window
    {
        private string name;
        private string tag;

        private Connection connection;

        public RequestWin(string name, string tag)
        {
            InitializeComponent();

            BtnAccept.Click += AcceptRequest;
            BtnDecline.Click += DeclineRequest;

            this.Title = "Incoming friend request";

            this.name = name;
            this.tag = tag;
            SetMessage();
        }

        private void DeclineRequest(object sender, RoutedEventArgs e)
        {
            connection.SendFriendRequestResponse(false, tag);
        }

        private void AcceptRequest(object sender, RoutedEventArgs e)
        {
            connection.SendFriendRequestResponse(true, tag);
        }

        private void SetMessage()
        {
            tb.Text = name + " wants to be your friend";
        }
        public void SetConnection(Connection connection)
        {
            this.connection = connection;
        }
    }
}
