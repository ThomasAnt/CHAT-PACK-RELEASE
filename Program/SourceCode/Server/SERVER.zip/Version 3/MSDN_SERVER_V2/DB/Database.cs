﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MSDN_SERVER_V3
{
    public class Database
    {

        private static string connectionString = @"server = (localdb)\MSSQLLocalDB";

        public static string GetUserNameFromDB(string tag)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                try
                {
                    SqlCommand command = new SqlCommand("SELECT UserName FROM Users WHERE tag=@tag", connection);
                    connection.Open();

                    command.Parameters.AddWithValue("@tag", Int16.Parse(tag));

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        return QResultReader.Username(reader, tag);
                    }
                }
                catch (Exception)
                {
                    Console.WriteLine("Username query failed");
                    return "ERROR";
                }
            }
        }

        public static string RunCommandUserManagement(string commandText, PacketType type)
        {
            // Given command text and connection string, asynchronously execute
            // the specified command against the connection. For this example,
            // the code displays an indicator as it is working, verifying the 
            // asynchronous behavior. 
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                 
                try
                {
                    string[] receivedData = commandText.Split(';');
                    SqlCommand command = new SqlCommand("", connection);
                    connection.Open();

                    SqlParameter nameParam;
                    SqlParameter tagParam;

                    switch (type)
                    {
                        case PacketType.Login:

                            command.CommandText =
                                "SELECT tag, password FROM Users WHERE username=@name";

                            nameParam = PrepareCommand_Name(receivedData[0]);
                            command.Parameters.Add(nameParam);
                            command.Prepare();

                            using (SqlDataReader reader = command.ExecuteReader())
                            {
                                return QResultReader.GetPwdQueryResult(reader, receivedData[1]);
                            }

                        case PacketType.Registiation:

                            command.CommandText =
                                "SELECT username FROM Users WHERE username=@name";

                            nameParam = PrepareCommand_Name(receivedData[0]);
                            command.Parameters.Add(nameParam);
                           
                            command.Prepare();

                            using (SqlDataReader reader = command.ExecuteReader())
                            {
                                if (QResultReader.GetUsernameQueryResult(reader, receivedData[0])) //Username available
                                    return InsertNewUser(receivedData[0],receivedData[1]);
                            }
                            
                            return "-1";

                        default:
                            return "-1";

                    }
                }
                catch (SqlException ex)
                {
                    Console.WriteLine("Error ({0}): {1}", ex.Number, ex.Message);
                    return "-1";
                }
                catch (InvalidOperationException ex)
                {
                    Console.WriteLine("Error: {0}", ex.Message);
                    return "-1";
                }
                catch (Exception ex)
                {
                    // You might want to pass these errors
                    // back out to the caller.
                    Console.WriteLine("Error: {0}", ex.Message);
                    return "-1";
                }
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="commandText"></param>
        /// <returns></returns>
        public static string RunCommandFriendManagement(string commandText, PacketType type)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    string[] receivedData = commandText.Split(';');
                    SqlCommand command = new SqlCommand("", connection);
                    connection.Open();

                    switch (type)
                    {
                        case PacketType.FriendListRequest:
                            command.CommandText =
                            "SELECT FriendName, concat('#', FriendTag) as FriendTag FROM FriendEntry WHERE UserTag = @tag";

                            SqlParameter tagParam = PrepareCommand_Tag(receivedData[0]);
                            command.Parameters.Add(tagParam);
                            command.Prepare();

                            using (SqlDataReader reader = command.ExecuteReader())
                            {
                                return QResultReader.GetFriendListQueryResult(reader);
                            }

                            
                        case PacketType.FriendRequest:
                            // MyTag;FriendTag
                            command.CommandText =
                                "SELECT username FROM Users WHERE tag=@tag";

                            command.Parameters.AddWithValue("@tag", Int16.Parse(receivedData[0]));

                            using (SqlDataReader reader = command.ExecuteReader())
                            {
                                if (!QResultReader.CheckTag(reader, receivedData[1].Substring(0, receivedData[1].Length - 5))) //Existing Tag
                                    return "";
                            }

                            command.CommandText =
                                "SELECT senderTag, receiverTag FROM FriendRequest WHERE senderTag = @sTag AND receiverTag = @rTag";

                            command.Parameters.AddWithValue("@sTag", Int16.Parse(receivedData[0]));
                            command.Parameters.AddWithValue("@rTag", Int16.Parse(receivedData[1].Substring(0, receivedData[1].Length-5)));

                            using (SqlDataReader reader = command.ExecuteReader())
                            {
                                if (QResultReader.GetTagQueryResult(reader, receivedData[0])) //No entry in the FriendRequest table
                                {
                                    return "AA"; //AlreadyAdded
                                }
                                return InsertPendingFriendRequest(receivedData[0], receivedData[1]);
                            }

                           

                        default:
                                return "";

                    }

                }
                catch (SqlException ex)
                {
                    Console.WriteLine("Error ({0}): {1}", ex.Number, ex.Message);
                    return "";
                }
                catch (InvalidOperationException ex)
                {
                    Console.WriteLine("Error: {0}", ex.Message);
                    return "";
                }
                catch (Exception ex)
                {
                    // You might want to pass these errors
                    // back out to the caller.
                    Console.WriteLine("Error: {0}", ex.Message);
                    return "";
                }

            }
        }

        public static SqlParameter PrepareCommand_Name(string value)
        {
            SqlParameter param = new SqlParameter("@name", SqlDbType.VarChar, 30);
            param.Value = value;

            return param;
        }
        public static SqlParameter PrepareCommand_Tag(string value)
        {
            SqlParameter param = new SqlParameter("@tag", SqlDbType.Int, 4);
            param.Value = value;

            return param;
        }
        public static SqlParameter PrepareCommand_Password(string value)
        {
            SqlParameter param = new SqlParameter("@password", SqlDbType.VarChar, 30);
            param.Value = value;

            return param;
        }

        public static string InsertNewUser(string username, string password)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                try
                {
                    SqlCommand command = new SqlCommand("INSERT INTO Users output INSERTED.Tag VALUES(@name,@password)", connection);                    
                    connection.Open();

                    command.Parameters.AddWithValue("@name", username);
                    command.Parameters.AddWithValue("@password", password.Substring(0, password.Length - 6));

                    int modified = (int)command.ExecuteScalar();

                    return Convert.ToString(modified);
                        
                }
                catch (SqlException ex)
                {
                    Console.WriteLine("InsertNewUser: " + ex);
                    return "-1";
                }
            }
        }

        public static string InsertPendingFriendRequest(string sendTag, string recievTag)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                try
                {
                    SqlCommand command = new SqlCommand("INSERT INTO FriendRequest VALUES (@senderTag, @receiverTag)", connection);
                    connection.Open();

                    command.Parameters.AddWithValue("@senderTag", sendTag);
                    command.Parameters.AddWithValue("@receiverTag", recievTag.Substring(0, recievTag.Length - 5));

                    command.ExecuteNonQuery();

                    return "OK";

                }
                catch (SqlException ex)
                {
                    Console.WriteLine("InsertPendingFriendRequest: " + ex);
                    return "";
                }
            }
        }

        public static string HandleFrienRequestResponse(string sendTag, string receiveTag, bool accepted)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    SqlCommand command = new SqlCommand("DELETE FROM FriendRequest WHERE senderTag=@sTag AND receiverTag=@rTag)", connection);
                    connection.Open();
                    
                    command.Parameters.AddWithValue("@sTag", Int16.Parse(sendTag));
                    command.Parameters.AddWithValue("@rTag", Int16.Parse(receiveTag.Substring(0, receiveTag.Length - 5)));

                    command.ExecuteNonQuery();

                    if (accepted)
                    {
                        command.CommandText =
                            "INSERT INTO FriendEntry VALUES(@sTag, (SELECT UserName FROM Users WHERE tag=@sTag), " +
                                                          "@rTag, (SELECT UserName FROM Users WHERE tag=@rTag))";

                        command.ExecuteNonQuery();

                        command.CommandText =
                             "INSERT INTO FriendEntry VALUES(@sTag, (SELECT UserName FROM Users WHERE tag=@sTag), " +
                                                          "@rTag, (SELECT UserName FROM Users WHERE tag=@rTag))";

                        command.ExecuteNonQuery();
                    }

                    return "OK";

                }
                catch (SqlException ex)
                {
                    Console.WriteLine("InsertPendingFriendRequest: " + ex);
                    return "";
                }
            }
        }

        public static bool ChangeUserName(string tag, string newName)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                try
                {
                    SqlCommand command = new SqlCommand("",connection);
                    
                    connection.Open();

                    for (int i = 0; i < 2; i++)
                    {

                        if (i == 0)
                        {
                            command.CommandText = "UPDATE Users SET UserName = @newName WHERE tag = @tag";

                            command.Parameters.AddWithValue("@newName", newName);
                            command.Parameters.AddWithValue("@tag", Int16.Parse(tag));
                        }
                        else
                        {
                            command.CommandText = "UPDATE FriendEntry SET UserName=@newName WHERE UserTag=@tag"; 
                        }

                        

                        command.ExecuteNonQuery();

                    }

                    return true;

                }
                catch (SqlException ex)
                {
                    Console.WriteLine("ChangeUserName: " + ex);
                    return false;
                }
            }
        }

        public static bool RemoveFriendEntry(string myTag, string friendTag)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                try
                {
                    SqlCommand command = new SqlCommand(
                        "DELETE FROM FriendEntry WHERE"
                        + "(UserTag = @myTag AND FriendTag = @friendTag) OR"
                        + "(UserTag = @friendTag AND FriendTag = @myTag)", connection);

                    connection.Open();

                    command.Parameters.AddWithValue("@myTag", Int16.Parse(myTag));
                    command.Parameters.AddWithValue("@friendTag", Int16.Parse(friendTag));

                    command.ExecuteNonQuery();

                    return true;

            }
            catch (SqlException ex)
            {
                Console.WriteLine("RemoveFriend: " + ex);
                return false;
            }
        }
    }


    }
}
