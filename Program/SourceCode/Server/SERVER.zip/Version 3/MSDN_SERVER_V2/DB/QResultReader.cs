﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MSDN_SERVER_V3
{
    class QResultReader
    {
        public static string Username(SqlDataReader reader, string tag)
        {           
            // Display the data within the reader.
            while (reader.Read())
            {
                // Display all the columns. 
                for (int i = 0; i < reader.FieldCount; i++)
                {
                    return (string)reader.GetValue(i);
                }
            }
            return "ERROR";
        }

        public static string GetFriendListQueryResult(SqlDataReader reader)
        {
            string friends = "";

            // Display the data within the reader.
            while (reader.Read())
            {
                // Display all the columns. 
                for (int i = 0; i < reader.FieldCount; i++)
                {
                    friends += (string)reader.GetValue(i);

                    if (i == 0)
                        friends += ",";                       
                }
                friends += ";";
            }
            if(friends != "")
                friends += "<RFL>"; //FRiendList

            return friends ;
        }

        public static string GetPwdQueryResult(SqlDataReader reader, string passwd)
        {
            string result = "";
            string tag = "";
            // Display the data within the reader.
            while (reader.Read())
            {
                // Display all the columns. 
                for (int i = 0; i < reader.FieldCount; i++)
                {
                    //Gets the current next value of the query


                    if (i == 0) //Tag
                    {
                        result = Convert.ToString((int)reader.GetValue(i));
                        tag = result;
                    }
                    else //Password
                    {
                        result = (string)reader.GetValue(i);

                        if (result == passwd.Substring(0, passwd.Length - 5)) //- <EOR>
                        {
                            Console.Write("{0} ", reader.GetValue(i));
                            Console.WriteLine();
                            //Password matches input -> return a valid the tag 
                            return tag;
                        }
                    }
                    
                }
            }

            //Password doesn't match input -> return a invalid the tag 
            return "-1";
        }

        public static bool GetUsernameQueryResult(SqlDataReader reader, string userName)
        {
            // Display the data within the reader.
            while (reader.Read())
            {
                // Display all the columns. 
                for (int i = 0; i < reader.FieldCount; i++)
                {
                    if ((string)reader.GetValue(i) == userName)
                    {
                        return false; //For the case of registration, or changing username, the username is already taken, so false is returned
                    }
                }
            }
            return true; // -//- ,username still available, return true
        }

        public static bool GetTagQueryResult(SqlDataReader reader, string tag)
        {
            while (reader.Read())
            { 
                for (int i = 0; i < reader.FieldCount; i++)
                {
                    if ((int)reader.GetValue(i) == int.Parse(tag))
                    {
                        return true; //Tag was found 
                    }
                }
            }
            return false; // Tag wasn't found
        }

        /// <summary>
        /// Checks if there is a entry with that specific tag
        /// </summary>
        /// <param name="reader"></param>
        /// <param name="tag"></param>
        /// <returns></returns>
        public static bool CheckTag(SqlDataReader reader, string tag)
        {
            return reader.Read();
        }
    }
}
