﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MSDN_SERVER_V3
{
    class EConsole
    {
        private static Stopwatch upTime;
        private static string input;
        private static bool shutdown;

        private static ConsoleColor defaultColor;


        public static void EEConsole()
        {
            upTime = new Stopwatch();
            input = "";
            shutdown = false;
            defaultColor = Console.ForegroundColor;
        }


        public static void StartConsoleInterface() {

            EEConsole();

            upTime.Start();          
            while (!shutdown)
            {
                input = Console.ReadLine();

                if (input == "!")
                {
                    WriteLine(ConsoleColor.Cyan, "Confirm shutdown by typing ! again");
                    if ((input = Console.ReadLine()) == "!")
                    {
                        WriteLine(ConsoleColor.DarkRed, "Shutdown");
                        Thread.Sleep(500);
                        Environment.Exit(0);
                    }
                }
                else if (input.ToLower() == "uptime")
                {
                    WriteLine(ConsoleColor.Cyan, FormatTime(upTime.Elapsed));
                }
                else if (input.ToLower() == "clients")
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;

                    foreach (KeyValuePair<string, Socket> item in AsynchronousSocketListener.GetDictionary())
                    {
                        Console.WriteLine(item.Key + "      " + item.Value.RemoteEndPoint);
                    }

                    Console.ForegroundColor = defaultColor;
                }
                else if (input != "")
                {
                    WriteLine(ConsoleColor.Gray, input + ":" + " command not found");
                }
                Console.Write("> ");
            }        
        }

        public static void WriteLine(ConsoleColor color, string msg)
        {
            Console.ForegroundColor = color;
            Console.WriteLine(msg);
            Console.ForegroundColor = defaultColor;
        }
        private static string FormatTime(TimeSpan time)
        {
            string[] elem = time.ToString().Split('.');
            return elem[0];
        }
    }
}
