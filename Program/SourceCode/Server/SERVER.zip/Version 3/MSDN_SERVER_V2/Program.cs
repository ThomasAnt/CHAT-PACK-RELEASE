﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Diagnostics;
using static System.Net.Mime.MediaTypeNames;
using System.Configuration;

namespace MSDN_SERVER_V3
{
    // State object for reading client data asynchronously  
    public class StateObject
    {
        // Client  socket.  
        public Socket workSocket = null;
        // Size of receive buffer.  
        public const int BufferSize = 1024;
        // Receive buffer.  
        public byte[] buffer = new byte[BufferSize];
        // Received data string.  
        public string str = "";
    }

    public enum PacketType
    {
        Registiation,
        Login,
        //Message
        FriendListRequest,
        FriendRequest
    };

    public class AsynchronousSocketListener
    {


        private static ManualResetEvent connectDone =
            new ManualResetEvent(false);
        private static ManualResetEvent sendDone =
            new ManualResetEvent(false);
        private static ManualResetEvent receiveDone =
            new ManualResetEvent(false);

        private static string serverVer = "3.05";

        static private Dictionary<string, Socket> userDictionary = new Dictionary<string, Socket>();

        // Thread signal.  
        public static ManualResetEvent allDone = new ManualResetEvent(false);

        public static Dictionary<string, Socket> GetDictionary() { return userDictionary; }

        public AsynchronousSocketListener()
        {
        }

        public static void StartListening()
        {
            Console.WriteLine("Starting Server...");

            // Data buffer for incoming data.  
            byte[] bytes = new Byte[1024];

            // Establish the local endpoint for the socket.  


            IPAddress ipAddress = IPAddress.Parse(GetLocalIPAddress());
            //IPAddress ipAddress = IPAddress.Parse("172.16.4.53");
            IPEndPoint localEndPoint = new IPEndPoint(ipAddress, 11000);

            //Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            //KeyValueConfigurationCollection confCollection = config.AppSettings.Settings;

            //confCollection[""].Value = ...
            //ConfigurationManager.AppSettings



            // Create a TCP/IP socket.  
            Socket listener = new Socket(ipAddress.AddressFamily,
                SocketType.Stream, ProtocolType.Tcp);

            // Bind the socket to the local endpoint and listen for incoming connections.  
            try
            {
                listener.Bind(localEndPoint);
                listener.Listen(100);

                EConsole.WriteLine(ConsoleColor.Green, "Server running on version " + serverVer + " \nServer Online\n" + "listening on " + localEndPoint.ToString() + "\n");

                for (int i = 0; i < 30; i++) Console.Write("_");
                Console.WriteLine("\n");


                while (true)
                {
                    // Set the event to nonsignaled state.  
                    allDone.Reset();

                    // Start an asynchronous socket to listen for connections.  
                    Console.WriteLine("Waiting for a connection...");


                    listener.BeginAccept(
                        new AsyncCallback(AcceptCallback),
                        listener);

                    // Wait until a connection is made before continuing.  
                    allDone.WaitOne();

                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }

            Console.ReadKey();
        }

        public static void AcceptCallback(IAsyncResult ar)
        {

            // Signal the main thread to continue.  
            allDone.Set();

            // Get the socket that handles the client request.  
            Socket listener = (Socket)ar.AsyncState;
            Socket handler = listener.EndAccept(ar);

            // Create the state object.  
            StateObject state = new StateObject();
            state.workSocket = handler;


            Thread clientThread = new Thread(() =>
            {
                try
                {
                    handler.BeginReceive(state.buffer, 0, StateObject.BufferSize, 0,
                        new AsyncCallback(ReadCallback), state);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("CRITICAL");
                    Console.WriteLine(ex);
                }
            });

            clientThread.Start();

        }

        public static void ReadCallback(IAsyncResult ar)
        {
            Socket handler = null;
            try
            {
                String content = String.Empty;

                // Retrieve the state object and the handler socket  
                // from the asynchronous state object.  
                StateObject state = (StateObject)ar.AsyncState;
                handler = state.workSocket;

                // Read data from the client socket.   
                int bytesRead = handler.EndReceive(ar);

                state.str = Encoding.ASCII.GetString(state.buffer, 0, bytesRead);
                content = state.str;

                string tag;

                #region EOR (EndOfRegistration)
                if (content.IndexOf("<EOR>") > -1)
                {
                    Console.WriteLine("Read {0} bytes from socket. \n Data : {1}",
                        content.Length, content);


                    if ((tag = Database.RunCommandUserManagement(content, PacketType.Registiation)) != "-1")
                    {
                        Send(handler, "ACKR;" + tag);
                        userDictionary.Add(tag, handler);
                    }
                    else
                    {
                        Send(handler, "NACKR");
                    }
                }

                #endregion

                #region EOL (EndOfLogin)
                else if (content.IndexOf("<EOL>") > -1)
                {
                    Console.WriteLine("Read {0} bytes from socket. \n Data : {1}",
                        content.Length, content);

                    if ((tag = Database.RunCommandUserManagement(content, PacketType.Login)) != "-1")
                    {
                        Send(handler, "ACKL;" + tag);
                        userDictionary.Add(tag, handler);
                    }
                    else
                    {
                        Send(handler, "NACKL");
                    }


                }
                #endregion

                #region EOF (EndOfFile) - Outdated
                else if (content.IndexOf("<EOF>") > -1)
                {
                    // All the data has been read from the   
                    // client. Display it on the console.  
                    Console.WriteLine("Read {0} bytes from socket. \n Data : {1}",
                        content.Length, content);
                    // Echo the data back to the client.  

                    string[] str = content.Split(';');

                    Console.WriteLine("Sending data..");

                    Send(handler, str[1]);
                    sendDone.WaitOne();


                    //handler.Shutdown(SocketShutdown.Both);
                    //handler.Close();

                }
                #endregion

                #region FLR (FriendListRequest)
                else if (content.IndexOf("<FLR>") > -1)
                {
                    Console.WriteLine("Read {0} bytes from socket. \n Data : {1}",
                        content.Length, content);

                    string friendList;

                    if ((friendList = Database.RunCommandFriendManagement(content,PacketType.FriendListRequest)) != "")
                    {
                        Send(handler, friendList);
                    }
                    else
                    {
                        Send(handler, "FLRF");
                    }
                }
                #endregion

                #region PFR (PendingFriendRequest)
                else if (content.IndexOf("<PFR>") > -1)
                {
                    Console.WriteLine("Read {0} bytes from socket. \n Data : {1}",
                        content.Length, content);
                    string result;

                    result = Database.RunCommandFriendManagement(content, PacketType.FriendRequest); //Trying to insert the FriendRequest into the Table
                    
                    if(result == "AA") //AlreadyAdded
                    {
                        Send(handler, "NACKFR_A"); //Failed to "send" the Friendrequest, because the request was already made
                    }
                    else if(result == "OK") //No errors occured
                    {
                        Send(handler, "ACKFR");

                        string[] elem = content.Split(';');
                        string senderTag = elem[0];
                        string receiverTag = elem[1].Substring(0, elem[1].Length - 5);
                      

                        if (userDictionary.ContainsKey(receiverTag)) //When user receives the FriendRequest, when online, otherwise on client restart
                        {
                            string senderName = "";
                            if ((senderName = Database.GetUserNameFromDB(senderTag)) != "ERROR")
                            {
                                Send(userDictionary[receiverTag], senderName + ";" + senderTag +"<IFR>"); // "SenderName;SenderTag<IFR>"
                            }
                        }
                    }

                     
                    else
                    {
                        Send(handler, "NACKFR_T"); //The User that should be added was not found
                    }
                }
                #endregion PFR

                #region FRR (FrienRequestResponse)
                else if(content.IndexOf("<FRR>") > -1)
                {
                    string[] elem = content.Split(';');
                    string value = elem[0];
                    string receiverTag = elem[1];
                    string senderTag = elem[2].Substring(0, elem[2].Length - 5);

                    bool accepted = false;
                    if (value == "A")
                        accepted = true;

                    if(Database.HandleFrienRequestResponse(senderTag, receiverTag, accepted) == "OK" && accepted)
                    {
                        Send(handler, "<FRA>");
                    }

                }
                #endregion

                #region RFR (RemoveFriendRequest)
                else if(content.IndexOf("<RFR>") > -1)
                {
                    string[] elem = content.Split(';');

                    if (Database.RemoveFriendEntry(elem[0], elem[1].Substring(0, elem[1].Length - 5)))
                    {
                        Send(handler, "ACKRF");
                    }
                    else
                        Send(handler, "NACKRF");
                }
                #endregion

                #region CUN (ChangeUserName)
                else if (content.IndexOf("<CUN>") > -1)
                {
                    string[] elem = content.Split(';');

                    if (Database.ChangeUserName(elem[0], elem[1].Substring(0, elem[1].Length - 5)))
                    {
                        Send(handler, "ACKCN");
                    }
                    else
                        Send(handler, "NACKCN");
                }
                #endregion

                else //Send normal message
                {
                    string[] elem = content.Split(';');

                    if(userDictionary.ContainsKey(elem[0]))
                    {
                        string msg = Encoding.ASCII.GetString(state.buffer, 0, bytesRead);

                        Send(userDictionary[elem[0]], msg);

                        Console.Write("Sending " + msg);
                    }
                    else
                    {
                        Console.WriteLine("Error while trying to send: User not online " + elem[0]);
                    }
                }

                // Not all data received. Get more.  
                handler.BeginReceive(state.buffer, 0, StateObject.BufferSize, 0,
                new AsyncCallback(ReadCallback), state);
            }
            catch (SocketException ex)
            {
                foreach (KeyValuePair<string,Socket> item in userDictionary)
                {
                    if(item.Value == handler)
                    {
                        userDictionary.Remove(item.Key);
                        EConsole.WriteLine(ConsoleColor.Blue, "Client Disconnected: " + item.Key);

                        break;
                    }
                }
            }


        }

        private static void Send(Socket handler, String data)
        {
            // Convert the string data to byte data using ASCII encoding.  
            Console.WriteLine("Trying to send " + data);
            byte[] byteData = Encoding.ASCII.GetBytes(data);

            // Begin sending the data to the remote device.  
            handler.BeginSend(byteData, 0, byteData.Length, 0,
                new AsyncCallback(SendCallback), handler);
        }

        private static void SendCallback(IAsyncResult ar)
        {
            try
            {
                // Retrieve the socket from the state object.  
                Socket handler = (Socket)ar.AsyncState;

                // Complete sending the data to the remote device.  
                int bytesSent = handler.EndSend(ar);
                Console.WriteLine("Sent {0} bytes to client.", bytesSent);

            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }

        public static void Main(String[] args)
        {
            Console.Title = "Server 3.0";
            Thread listenThread = new Thread(StartListening);
            listenThread.Start();

            EConsole.StartConsoleInterface();
        }

        public static string GetLocalIPAddress()
        {
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    return ip.ToString();
                }
            }
            throw new Exception("No network adapters with an IPv4 address in the system!");
        }
    }
}
